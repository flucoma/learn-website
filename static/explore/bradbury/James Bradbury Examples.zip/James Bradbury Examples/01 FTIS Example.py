'''
01 FTIS Example
In this script, we take a look at Bradbury's Finding Things In Stuff library.

Install the library with pip install ftis. Also make sure you have the latest
version of the FluCoMa CLI tools in your path.
https://github.com/jamesb93/ftis
'''

# Import the world and corpus classes:
from ftis.world import World
from ftis.corpus import Corpus

# Also, import the various analysers you wish to use:
from ftis.analyser import (
    FluidMFCC, 
    AgglomerativeClustering, 
    Stats, 
    UMAP, 
    Standardise
)

# Load a folder of sounds we wish to analyse, and set an output location for the results:
src = Corpus("path/to/my/sounds")
out = 'path/to/output'

# Create an instance of the world object:
world = World(sink = out)

# Connect processes with >>:
src >> FluidMFCC(cache = True) >> Stats(numderivs = 1, flatten = True, cache = False) >> Standardise(cache = False) >> UMAP(components = 6) >> AgglomerativeClustering(numclusters = 4)

# Run the script:
if __name__ == "__main__":
    world.run()
'''
02 Reathon Example
In this script, we take a look at Bradbury's Reathon library.

Install using pip install reathon.
https://github.com/jamesb93/reathon
'''

# Import the various node classes from reathon:
from reathon.nodes import *

# And import the random module for some fun:
import random

# Create a blank project:
myProject = Project()

# Add a track:
myTrack = myProject.add(Track())

# Add an audio item to the track:
myTrack.add(Item(
    Source(file = 'path/to/my/audio/file'),
    position = 2
))

# Of course, these kinds of operations can be performed programatically - think of the possibilities!
for i in range(100):
    myProject.add(
        Track(
            Item(
                Source(file = 'path/to/my/audio/file')
            )
            position = random.randint(0, 10)
            length = random.random() * 10
        )
    )

# Save the project to disk as an rpp file, and open in reaper to see the results:
myProject.write('my/save/location.rpp')
'''
04 Micro-Clustering
In this script, we see how Bradbury performed his micro-clustering using an older version of FTIS.

https://github.com/jamesb93/interferences/blob/0773d279b98925cfa7a8b4008ab901d19af5c45b/micro_clustering.py
'''

# Import the FTIS analysers:
from ftis.analyser import (
    FluidMFCC, 
    HDBSCluster, 
    Stats, 
    UMAP, 
    Standardise,
    Normalise
)
from ftis.process import FTISProcess as Chain

src = 'path/to/source'
folder = 'path/for/output'

process = Chain(
    source=src, 
    folder=folder
)

# Chain all of the processes together:
process.add(
    FluidMFCC(cache=True),
    Stats(numderivs=1, flatten=True, cache=False),
    Standardise(cache=False),
    Normalise(cache=False),
    UMAP(components=6),
    HDBSCluster(minclustersize=10)
)

# Run the process, this will create a json file that can be used with the exploration patch.
if __name__ == "__main__":
    process.run()
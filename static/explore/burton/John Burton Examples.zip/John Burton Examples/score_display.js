// Mgraphics init:
mgraphics.init();
inlets = 1;
outlets = 1;
setinletassist(0, 'Ctrl In');
setoutletassist(0, 'Ctrl Out');

this.box_info = update_box_info(this);
this.line_height = get_line_height();
this.full_length_pix = 18000;
this.line_length_pix = 1800;
this.current_playhead_real_pos = 0;

this.playhead_dict_name = jsarguments[1];
this.playhead_dict = new Dict(this.playhead_dict_name);

this.human_score_dict_name = jsarguments[2];
this.human_score_dict = new Dict(this.human_score_dict_name);

this.machine_score_dict_name = jsarguments[3];
this.machine_score_dict = new Dict(this.machine_score_dict_name);

this.style = {
    bg_col : [0., 0., 0., 1.],
    line_col : [1., 1., 1., 1.],
    playhead_col : [1., 1., 1., 1.],
    line_width : 1,
    playhead_width : 2,
    human_block_col : [1., 0., 0., 1.],
    machine_block_col : [0., 0.909804, 0.960784, 1.],
    score_block_width : 1,
    block_done_col : [0. , 1., 0., 1.]
};

function set_current_playhead_pos(pos){
    this.current_playhead_real_pos = pos;
}

function set_full_len_pix(val){
    this.full_length_pix = val;
    this.line_length_pix = this.full_length_pix / 10;
};

function get_dims(){
    outlet(0, "box_width " + String(this.box_info[2]));
};

function update(){
    mgraphics.redraw();
};

function paint(){
    draw_bg();

    draw_human_score();
    draw_machine_score();
    
    draw_lines();
    draw_playhead();
};

function draw_human_score(){
    block_list = always_array(this.human_score_dict.getkeys());

    with(mgraphics){
        for(item in block_list){
            this_item = this.human_score_dict.get(item);
            this_shape = this_item[0];
            onset_coords = onset_to_x_y(this_item[1]);
            this_len = pix_to_len(this_item[2]);
            this_hei = amp_to_hei(this_item[3]);

            

            if(this_shape == 2){
                // Block
                set_source_rgba(this.style.human_block_col);
                rectangle([onset_coords[0], onset_coords[1] + (this.line_height - this_hei), this_len, this_hei]);
                fill();

                if(this_item[1] + this_item[2] < this.current_playhead_real_pos){
                    set_source_rgba(this.style.block_done_col);
                    set_line_width(this.style.score_block_width);
                    
                    rectangle([onset_coords[0], onset_coords[1] + (this.line_height - this_hei), this_len, this_hei]);
                    
                    stroke();
                };
            }
            else if (this_shape == 0){
                // Ramp up
                set_source_rgba(this.style.human_block_col);
                move_to(onset_coords[0], onset_coords[1] + this.line_height);
                line_to(onset_coords[0] + this_len, onset_coords[1] + (this.line_height - this_hei));
                line_to(onset_coords[0] + this_len, onset_coords[1] + this.line_height);
                line_to(onset_coords[0], onset_coords[1] + this.line_height);
                fill();

                if(this_item[1] + this_item[2] < this.current_playhead_real_pos){
                    set_source_rgba(this.style.block_done_col);
                    set_line_width(this.style.score_block_width);
                    
                    move_to(onset_coords[0], onset_coords[1] + this.line_height);
                    line_to(onset_coords[0] + this_len, onset_coords[1] + (this.line_height - this_hei));
                    line_to(onset_coords[0] + this_len, onset_coords[1] + this.line_height);
                    line_to(onset_coords[0], onset_coords[1] + this.line_height);
                    
                    stroke();
                };
            }else{
                // Ramp down
                set_source_rgba(this.style.human_block_col);
                move_to(onset_coords[0], onset_coords[1] + (this.line_height - this_hei));
                line_to(onset_coords[0], onset_coords[1] + this.line_height);
                line_to(onset_coords[0] + this_len, onset_coords[1] + this.line_height);
                line_to(onset_coords[0], onset_coords[1] + (this.line_height - this_hei));
                fill();

                if(this_item[1] + this_item[2] < this.current_playhead_real_pos){
                    set_source_rgba(this.style.block_done_col);
                    set_line_width(this.style.score_block_width);
                    
                    move_to(onset_coords[0], onset_coords[1] + (this.line_height - this_hei));
                    line_to(onset_coords[0], onset_coords[1] + this.line_height);
                    line_to(onset_coords[0] + this_len, onset_coords[1] + this.line_height);
                    line_to(onset_coords[0], onset_coords[1] + (this.line_height - this_hei));
                    
                    stroke();
                };
            };  
        };
    };
};

function draw_machine_score(){
    
    block_list = always_array(this.machine_score_dict.getkeys());

    with(mgraphics){
        for(item in block_list){
            this_item = this.machine_score_dict.get(item);
            if(this_item != null){
                this_shape = this_item[0];
                onset_coords = onset_to_x_y(this_item[1]);
                this_len = pix_to_len(this_item[2]);
                this_hei = amp_to_hei(this_item[3]);
    
                set_source_rgba(this.style.machine_block_col);
                set_line_width(this.style.score_block_width);
    
                if(this_shape == 2){
                    // Block
                    rectangle([onset_coords[0], onset_coords[1] + (this.line_height - this_hei), this_len, this_hei]);
                    stroke();
                }
                else if (this_shape == 0){
                    // Ramp up
                    move_to(onset_coords[0], onset_coords[1] + this.line_height);
                    line_to(onset_coords[0] + this_len, onset_coords[1] + (this.line_height - this_hei));
                    line_to(onset_coords[0] + this_len, onset_coords[1] + this.line_height);
                    line_to(onset_coords[0], onset_coords[1] + this.line_height);
                    stroke();
                }else{
                    // Ramp down
                    move_to(onset_coords[0], onset_coords[1] + (this.line_height - this_hei));
                    line_to(onset_coords[0], onset_coords[1] + this.line_height);
                    line_to(onset_coords[0] + this_len, onset_coords[1] + this.line_height);
                    line_to(onset_coords[0], onset_coords[1] + (this.line_height - this_hei));
                    stroke();
                };  
            }
            
        };
    };
};

function amp_to_hei(amp){
    return scaler(amp, 0., 100., 0., this.line_height);
}

function pix_to_len(pix){
    //return scaler(pix, 0., this.line_length_pix, 0., this.box_info[2]);
    return scaler(pix, 0., this.full_length_pix, 0., this.box_info[2] * 10);
    
};

function onset_to_x_y(pix){
    pix_x = pix % this.line_length_pix;
    y_count = Math.floor(pix / this.line_length_pix);

    real_x = scaler(pix_x, 0., this.line_length_pix, 0., this.box_info[2]);
    real_y = y_count * this.line_height;

    return [real_x, real_y];
};

function scaler(val, old_min, old_max, new_min, new_max){
    return new_min + (((val - old_min) * (new_max - new_min)) / (old_max - old_min));
}

function always_array(query){
    if(query == null){
        query = [];
    }
    else if(typeof query == 'string'){
        query = [query];
    }

    return query;
}

function draw_lines(){
    with(mgraphics){
        for(i = 1; i < 10; i++){
            this_y = (i * this.line_height) - (this.style.line_width * 0.5);
            set_source_rgba(this.style.line_col);
            set_line_width(this.style.line_width);
            move_to(0, this_y);
            line_to(this.box_info[2], this_y);
            stroke();
        };
    };
};

function draw_bg(){
    with(mgraphics){
        set_source_rgba(this.style.bg_col);
        rectangle([0, 0, this.box_info[2], this.box_info[3]]);
        fill();
    };
};

function draw_playhead(){
    with(mgraphics){
        playhead_pos = [this.playhead_dict.get('x'), this.playhead_dict.get('y')];
        playhead_x = playhead_pos[0] - (this.style.playhead_width * 0.5);
        playhead_y = playhead_pos[1] * this.line_height;
        set_source_rgba(this.style.playhead_col);
        set_line_width(this.style.playhead_width);
        move_to(playhead_x, playhead_y);
        line_to(playhead_x, playhead_y + this.line_height);
        stroke();
    };
};

function update_box_info(obj){
    x = obj.box.rect[0];
    y = obj.box.rect[1];
    w = obj.box.rect[2] - obj.box.rect[0];
    h = obj.box.rect[3] - obj.box.rect[1];

    return [x, y, w, h];
};

function onresize(){
    this.box_info = update_box_info(this);
    this.line_height = get_line_height();
    get_dims();
    update();
};

function get_line_height(){
    line_height = this.box_info[3] / 10;
    return line_height;
};
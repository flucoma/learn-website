'''
---- Other reductions ----
With this script, we can take a standardized corpus description exported from the "03 Corpus Exploration"
Max patch, and use scikit-learn to perform some other dimensionality reductions.
Set the output folder to the place that you saved the PCA, MDS and UMAP reductions from the Max patch.
The reductions will be saved to this folder, and will then be able to be loaded back into the patch 
for interation.
'''

import os

# Set the source file, output folder and file prefix here:
params = {
    "corpus_description_file" : os.path.join(os.getcwd(), 'data_reductions/high_res_desc.json'),
    "output_folder" : os.path.join(os.getcwd(), 'data_reductions'),
    "output_file_prefix" : 'High Res Example'
}

import json
import numpy as np
from sklearn.manifold import TSNE
from sklearn.preprocessing import MinMaxScaler
from sklearn.manifold import Isomap
from sklearn.manifold import LocallyLinearEmbedding
from sklearn.manifold import SpectralEmbedding

def process():
    original_data = load_json(params["corpus_description_file"])
    np_data = convert_to_np(original_data)

    print('T-SNE Processing...')
    tsne_data = process_tsne(np_data)
    export_data(original_data, tsne_data, 'tsne')

    print('Isomap Processing...')
    isomap_data = process_isomap(np_data)
    export_data(original_data, isomap_data, 'isomap')

    print('Locally Linear Embedding Processing...')
    lle_data = process_lle(np_data)
    export_data(original_data, lle_data, 'locally_linear_embedding')

    print('Spectral Embedding Processing...')
    spec_data = process_spec(np_data)
    export_data(original_data, spec_data, 'spectral_embedding')

def load_json(path):
    f = open(path)
    data = json.load(f)
    f.close()
    return data

def write_json(data, path):
    with open(path, 'w') as outfile:
        json.dump(data, outfile, indent = 4)

def export_data(slice_data, reduced_data, type):
    to_export = {
        "cols" : 2,
        "data" : {}
    }

    count = 0
    for item in slice_data["data"]:
        to_export["data"][item] = reduced_data[count].tolist()
        count = count + 1
        
    write_json(to_export, os.path.join(params["output_folder"], params["output_file_prefix"] + "_scikit-learn_" + type + '.json'))

def convert_to_np(data):
    global_array = np.array([])
    for item in data["data"]:
        this_array = np.array(data["data"][item])
        if np.size(global_array) == 0:
            global_array = np.append(global_array, this_array)
        else:
            global_array = np.vstack((global_array, this_array))

    return global_array

def process_tsne(data):
    tsne = TSNE(n_components = 2)
    reduced = tsne.fit_transform(data)
    normed = min_max(reduced)
    return normed

def process_isomap(data):
    iso = Isomap(n_components = 2)
    reduced = iso.fit_transform(data)
    normed = min_max(reduced)
    return normed

def process_lle(data):
    lle = LocallyLinearEmbedding(n_components = 2, method='standard')
    reduced = lle.fit_transform(data)
    normed = min_max(reduced)
    return normed

def process_spec(data):
    spec = SpectralEmbedding(n_components = 2)
    reduced = spec.fit_transform(data)
    normed = min_max(reduced)
    return normed

def min_max(data):
    scaled = MinMaxScaler((0.1, 0.9)).fit_transform(data)
    return scaled

process()
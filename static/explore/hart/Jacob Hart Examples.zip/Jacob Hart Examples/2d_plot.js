// Mgraphics init:
mgraphics.init();
inlets = 1;
outlets = 1;
setinletassist(0, 'Ctrl In');
setoutletassist(0, 'Ctrl Out');

this.data_dict_name = jsarguments[1];
this.data_dict = new Dict(this.data_dict_name);
this.cursor_dict_name = jsarguments[2];
this.cursor_dict = new Dict(this.cursor_dict_name);
this.box_info = update_box_info(this);

this.style = {
    bg_col : [1., 1., 1., 1.],
    node_size_factor : 5
};

this.workspace = {
    x_offset : 0,
    y_offset : 0,
    zoom : 1.
};

this.mouse = {
    mouse_x : 0,
    mouse_y : 0,
    mouse_button : 0,
    shift_state : false,
    dragging : false,
    double_click : false,
    clicked_down : false
};

function set(prop, val){
    if(prop == 'zoom'){
        this.workspace.zoom = val;
    } else if(prop == 'x_offset'){
        this.workspace.x_offset = val;
    } else if(prop == 'y_offset'){
        this.workspace.y_offset = val;
    } else if(prop == 'node_size_factor'){
        this.style.node_size_factor = val;
    } else if(prop == 'bg_col'){
        args = arrayfromargs(messagename , arguments);
        this.style.bg_col = [args[2], args[3], args[4], args[5]];
    };

    update();
};

function update_data(){
    this.data_dict_name = jsarguments[1];
    this.data_dict = new Dict(this.data_dict_name);
    update();
};

function update(){
    process_mouse();

    mgraphics.redraw();
};

function update_draw(){
    mgraphics.redraw();
};

function process_mouse(){
    mouse_input = get_mouse_input();

    if(mouse_input == 1 || mouse_input == 0 || mouse_input == 2){
        abs_cursor = get_cursor_absolute(this.mouse.mouse_x, this.mouse.mouse_y);
        this.cursor_dict.replace('x', abs_cursor[0]);
        this.cursor_dict.replace('y', abs_cursor[1]);

        if(mouse_input == 1){
            outlet(0, 'cursor_moved ' + String(abs_cursor[0]) + ' ' + String(abs_cursor[1]));
        }; 
    };   
}

function get_cursor_absolute(mouse_x, mouse_y){
    unscaled = get_absolute_coords(mouse_x, mouse_y);
    return [unscaled[0] / this.box_info[2], unscaled[1] / this.box_info[3]];
}

function paint(){
    draw_bg();
    draw_nodes();
    draw_cursor();
};

function draw_nodes(){
    node_list = this.data_dict.getkeys();
    for(node in node_list){
        draw_node(this.data_dict.get(node_list[node]));
    };
};

function draw_cursor(){
    with(mgraphics){
        set_source_rgba(this.cursor_dict.get('col'));
        this_coords = get_relative_coords(this.cursor_dict.get('x') * this.box_info[2], this.cursor_dict.get('y') * this.box_info[3]);
        this_size = get_relative_size(this.cursor_dict.get('size') * this.style.node_size_factor);
        ellipse(this_coords[0] - (this_size * 0.5), this_coords[1] - (this_size * 0.5), this_size, this_size);
        fill();
    };
};

function draw_node(node_data){
    with(mgraphics){
        set_source_rgba(node_data.get('col'));
        this_coords = get_relative_coords(node_data.get('x') * this.box_info[2], node_data.get('y') * this.box_info[3]);
        this_size = get_relative_size(node_data.get('size') * this.style.node_size_factor);
        ellipse(this_coords[0] - (this_size * 0.5), this_coords[1] - (this_size * 0.5), this_size, this_size);
        fill();
    };
};

function draw_bg(){
    with(mgraphics){
        set_source_rgba(this.style.bg_col);
        rectangle([0, 0, this.box_info[2], this.box_info[3]]);
        fill();
    };
};

function update_box_info(obj){
    x = obj.box.rect[0];
    y = obj.box.rect[1];
    w = obj.box.rect[2] - obj.box.rect[0];
    h = obj.box.rect[3] - obj.box.rect[1];

    return [x, y, w, h];
};

function get_relative_coords(absolute_x, absolute_y){
    // Give absolute coordinates, and return coordinates relative to the zoom and offset.
    // Returns the following array: [relative_x, relative_y]
    relative_x = (absolute_x + this.workspace.x_offset) * this.workspace.zoom;
    relative_y = (absolute_y + this.workspace.y_offset) * this.workspace.zoom;

    return [relative_x, relative_y];
};

function get_absolute_coords(relative_x, relative_y){
    // Give coordinates that are relative to the zoom and offset, and return the absolute corrdinates.
    // Returns the following array: [absolute_x, absolute_y]
    absolute_x = (relative_x / this.workspace.zoom) - this.workspace.x_offset;
    absolute_y = (relative_y / this.workspace.zoom) - this.workspace.y_offset;

    return [absolute_x, absolute_y];
};

function get_relative_size(absolute_size){
    // Give absolute size, return size relative to the zoom and offset.
    return absolute_size * this.workspace.zoom;
};

function onresize(){
    this.box_info = update_box_info(this);
    update();
};

function ondrag(x, y, button, shift){
    this.mouse.mouse_x = x;
    this.mouse.mouse_y = y;
    this.mouse.mouse_button = button;
    if(shift == 1){this.mouse.shift_state = true;}else{this.mouse.shift_state = false;};
    this.mouse.dragging = true;
    this.mouse.double_click = false;
    update();
};

function onclick(x, y, button, shift){
    this.mouse.mouse_x = x;
    this.mouse.mouse_y = y;
    this.mouse.mouse_button = button;
    if(shift == 1){this.mouse.shift_state = true;}else{this.mouse.shift_state = false;};
    this.mouse.dragging = false;
    this.mouse.double_click = false;
    this.mouse.clicked_down = true;
    update();
};

function onidle(x, y, button, shift){
    this.mouse.mouse_x = x;
    this.mouse.mouse_y = y;
    this.mouse.mouse_button = button;
    if(shift == 1){this.mouse.shift_state = true;}else{this.mouse.shift_state = false;};
    this.mouse.dragging = false;
    this.mouse.double_click = false;
    update();
};

function get_mouse_input(){
    // Get the current mouse state:
    // -1: none
    // 0: click down
    // 1: click up
    // 2: drag
    // 3: click down shift
    // 4: click up shift
    // 5: drag shift
    // 6: dblclick up
    to_return = -1;

    if(this.mouse.dragging == true && this.mouse.mouse_button == 1){
        if(this.mouse.shift_state == true){
            to_return = 5;
            // DRAGGING SHIFT
        } else{
            to_return = 2;
            // DRAGGING NO SHIFT
        };
    }
    else{
        if(this.mouse.clicked_down == true && this.mouse.mouse_button == 1){

            if(this.mouse.shift_state == true){
                to_return = 3;
                // CLICK DOWN SHIFT
            } else{
                to_return = 0;
                // CLICK DOWN NO SHIFT
            };
        };
        if(this.mouse.clicked_down == true && this.mouse.mouse_button == 0){
            this.mouse.clicked_down = false;
            this.mouse.dragging = false;
            if(this.mouse.shift_state == true){
                to_return = 4;
                // CLICKED UP SHIFT
            }else{
                to_return = 1;
                // CLICKED UP NO SHIFT
            };
        };
        if(this.mouse.double_click == true){
            to_return = 6;
            this.mouse.double_click = false;
            // DOUBLE CLICKED
        };
    };

    return to_return;
};
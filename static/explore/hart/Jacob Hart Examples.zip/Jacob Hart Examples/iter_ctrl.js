inlets = 1;
outlets = 1;

this.dict_name = jsarguments[1];

this.database = {};
this.full_state_list = [];
this.full_state_list_reversed = [];

this.file_name_mode = 0;

function set_file_name_mode(val){
    this.file_name_mode = val;
};

function get_state(index){
    to_ret = [];

    for (i = 0; i < this.full_state_list_reversed.length; i++ ){
        current_set = this.full_state_list_reversed[i];
        element = current_set[index % current_set.length];
        to_ret.push(element);
        index = Math.floor(index / current_set.length)
    };

    final_arr = to_ret.reverse();

    out_string = 'set_params ';
    file_name_string = 'file_name ';

    for(i = 0; i < final_arr.length; i++){
        if (typeof final_arr[i][1] === 'string' || final_arr[i][1] instanceof String){
            out_string = out_string + '\"' + String(final_arr[i][0]) + '\" \"' + String(final_arr[i][1]) + '\" ';
        }else{
            out_string = out_string + '\"' + String(final_arr[i][0]) + '\" ' + String(final_arr[i][1]) + ' ';
        };

        if(this.file_name_mode == 0){
            file_name_string = file_name_string + String(final_arr[i][2]) + '_' + String(final_arr[i][1]);
        }
        else if(this.file_name_mode == 1){
            file_name_string = file_name_string + String(final_arr[i][0]) + '_' + String(final_arr[i][1]);
        }
        else if(this.file_name_mode == 2){
            file_name_string = file_name_string + String(final_arr[i][0]) + '_' + String(final_arr[i][2]) + '_' + String(final_arr[i][1]);
        }
        
        if(i != final_arr.length -1){
            file_name_string = file_name_string + '_';
        }
    };

    outlet(0, file_name_string);
    outlet(0, out_string);
};

function process_params(){
    this.database = {};
    this.full_state_list = [];
    this.full_state_list_reversed = [];

    param_dict = new Dict(this.dict_name);
    param_list = param_dict.getkeys();
    num_states = 1;
    throw_error = false;

    if(param_list != null){
        if(Array.isArray(param_list) == false){
            param_list = [param_list];
        };
    
        for(i = 0; i < param_list.length; i++){
            this_entry = {};
            this_settings = param_dict.get(param_list[i] + '::settings');

            if(this_settings[0] == 'range'){
                if(this_settings.length != 4 || this_settings[3] == 0){

                }else{
                    state_list = [];
                    the_range = this_settings[2] - this_settings[1];
                    num_steps = the_range / this_settings[3];
    
                    for(j = 0; j < num_steps; j++){
                        state_list.push(this_settings[1] + (j * this_settings[3]));
                    };
                    state_list.push(this_settings[2]);
    
                    this_entry['states'] = state_list;
                    this_entry['num_states'] = state_list.length;
                }
                
            }
            else if(this_settings[0] == 'set_list'){
                state_list = [];
                for(j = 1; j < this_settings.length; j++){
                    state_list.push(this_settings[j]);
                };
                this_entry['states'] = state_list;
                this_entry['num_states'] = state_list.length;
            };

            named_states = []
            for(j = 0; j < state_list.length; j++){
                entry_list = [];
                entry_list.push(param_dict.get(param_list[i] + '::param_name'));
                entry_list.push(state_list[j]);
                entry_list.push(param_dict.get(param_list[i] + '::entry_name'));
                named_states.push(entry_list);
            }
            this_entry['full_state_list'] = named_states;
            this.full_state_list.push(named_states);

            this_entry['entry_name'] = param_dict.get(param_list[i] + '::entry_name');
            this_entry['param_name'] = param_dict.get(param_list[i] + '::param_name');
            this_entry['unique_id'] = param_list[i];

            this.database[param_list[i]] = this_entry;

            num_states = num_states * state_list.length;
        };

        
    }
    else{
        throw_error = true;
    } 

    if(throw_error != true){
        outlet(0, 'num_states ' + String(num_states));
        this.full_state_list_reversed = this.full_state_list.reverse();
    }
    else{
        outlet(0, 'num_states 0');
    }
};

function print_database(){
    for(entries in this.database){
        post(String(entries) + '\n');
        for(items in this.database[entries]){
            post(String(items) + ': ' + String(this.database[entries][items]) + '\n');
        };
        post('\n');
    };
};

function print_named_states(){
    for(i = 0; i < this.full_state_list.length; i++){
        post('List ' + String(i) + ":\n");
        for(j = 0; j < this.full_state_list[i].length; j++){
            post(String(this.full_state_list[i][j]) + '\n')
        }
        post('\n');
    };
};
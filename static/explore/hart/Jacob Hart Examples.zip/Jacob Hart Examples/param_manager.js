// Max obj config:
inlets = 1;
outlets = 1;
setinletassist(0, 'Ctrl In');
setoutletassist(0, 'Ctrl Out');

// Dependecies: 
this.pc = require("patch_ctrl");

// Where to put stuff:
this.dimensions = {
    x : 197.02316,
    y : 238.,
    w : 553.,
    h : 22.,
    padding : 1
};

// Where the data will be stored:
this.database = {};
this.att_count = 0;

function reset_params(){
    // For resetting when the patch loads:
    this.pc.reset(this, term='PARAM_IT');
    this.database = {};
    this.att_count = 0;
};

function remove(unique_index){
    // We will be going through all of the attribute object, and finding the one to remove:
    var obj_to_remove;

    // Find the attributes that will move:
    moving = find_move_entries(unique_index);

    // Iterate through all of the attribute bpatcher objects:
    obj = this.patcher.firstobject;
    for(i = 0; i < this.patcher.count; i++){
        if(obj.varname.indexOf('PARAM_IT') > -1){
            // Get the attributes unique id:
            this_creation_index = obj.getboxattr('args')[1];

            // Move this object if it need moving:
            if(array_includes(moving, this_creation_index)){
                current_pos = obj.getboxattr('presentation_position');
                obj.setboxattr('presentation_position', [current_pos[0], current_pos[1] - (this.dimensions.h + this.dimensions.padding)]);
                obj.setboxattr('patching_position', [current_pos[0], current_pos[1] - (this.dimensions.h + this.dimensions.padding)]);
            };
                
            // Check if this attribute is the one to remove
            if(this_creation_index == unique_index){
                // If so, define it as the one to be removed, and check that we have removed.
                obj_to_remove = obj;
            };
        };
        obj = obj.nextobject;
    };

    // Remove the target attribute object:
    this.patcher.remove(obj_to_remove);

    // Finally remove the entry from the global database:
    delete this.database[unique_index];
};

function array_includes(arr, el){
    // return true if element el is in array arr:
    to_ret = false;
    for(ii = 0; ii < arr.length; ii++){
        if(arr[ii] == el){
            to_ret = true;
        };
    };

    return to_ret;
};

function find_move_entries(to_remove){
    // Given an entry to remove, return a list of entries that will need to be moved.
    have_found = false;
    to_move = [];
    for(items in this.database){
        if(have_found == true){
            to_move.push(items);
        };
        if(items == to_remove){
            have_found = true;
        };
    };

    return to_move;
};

function append_param(){
    // On each append, increase the global attribute count:
    this.att_count++;

    // Create an entry in the database at key global count (so will always be unique):
    num_keys = Object.keys(this.database).length;
    database_entry = {
        current_index : num_keys,
        unique_idx : this.att_count - 1
    };
    this.database[this.att_count - 1] = database_entry;

    // Create attribute bpatcher:
    this_attr = this.pc.create_obj(this, this.dimensions.x, this.dimensions.y + (this.dimensions.h * num_keys), 'bpatcher', 
                                ['it_param.maxpat', 
                                '@args', 'main_it_param_dict', this.att_count - 1, 
                                '@presentation', 1,
                                '@patching_rect', this.dimensions.x, this.dimensions.y + (this.dimensions.h * num_keys) + (num_keys * this.dimensions.padding), this.dimensions.w, this.dimensions.h,
                                '@presentation_rect', this.dimensions.x, this.dimensions.y + (this.dimensions.h * num_keys) + (num_keys * this.dimensions.padding), this.dimensions.w, this.dimensions.h],
                                term='PARAM_IT');

    // Retrieve the pass from object and connect to attribute bpatcher:
    pass_from_params = this.pc.find_obj(this, 'pass_from_params');
    this.patcher.connect(this_attr, 0, pass_from_params, 0);
};
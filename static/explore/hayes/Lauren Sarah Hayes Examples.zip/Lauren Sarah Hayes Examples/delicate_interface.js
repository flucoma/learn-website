mgraphics.init();
inlets = 1;
outlets = 1;
setinletassist(0, 'Ctrl In');
setoutletassist(0, 'Ctrl Out');

this.style = {
    bg_col : [1, 1, 1, 1],
    node_size : 8
}

this.node_speed = 0.05;

this.mouseState = [0, 0, 0, 0, false, false, false]; // x, y, button, shift, , dblclicked
this.shiftState = false;

this.box_info = get_box_info(this);
this.node_info = {
    node_1 : {
        pos : [0., 0.],
        col : [1, 0, 0, 1],
        freeze : 0,
        write : 0
    },
    node_2 : {
        pos : [1., 0.],
        col : [1, 0, 0, 1],
        freeze : 0,
        write : 0
    },
    node_3 : {
        pos : [1., 1.],
        col : [1, 0, 0, 1],
        freeze : 0,
        write : 0
    }
}

function update(){
    mgraphics.redraw();
}

function paint(){
    draw_bg();

    draw_nodes();
}

function set_write(node, val){
    this.node_info[node]['write'] = val;
}

function set_freeze(node, val){
    this.node_info[node]['freeze'] = val;
}

function get_data(){


    for(nodes in this.node_info){
        if(this.node_info[nodes]['freeze'] == 0 && this.node_info[nodes]['write'] != 1){
            this.node_info[nodes]['pos'] = get_random_pos(this.node_info[nodes]['pos']);
        }
        outlet(0, nodes + ' ' + String(this.node_info[nodes]['pos'][0]) + ' ' + String(this.node_info[nodes]['pos'][0]));
    }

    update();
    
}

function get_random_pos(current_pos){

    to_ret = []

    direc_choose_x = Math.random();
    direc_choose_y = Math.random();

    if(direc_choose_x > 0.5){
        expected = current_pos[0] + this.node_speed

        if(expected > 1){
            to_ret.push(1)
        }else{
            to_ret.push(expected)
        }

        
    }else{
        expected = current_pos[0] + (this.node_speed * -1)

        if(expected < 0){
            to_ret.push(0)
        }else{
            to_ret.push(expected)
        }
    }

    if(direc_choose_y > 0.5){
        expected = current_pos[1] + this.node_speed

    if(expected > 1){
        to_ret.push(1)
    }else{
        to_ret.push(expected)
    }

    
}else{
    expected = current_pos[1] + (this.node_speed * -1)

    if(expected < 0){
        to_ret.push(0)
    }else{
        to_ret.push(expected)
    }
}

    return to_ret
}

function draw_nodes(){
    with(mgraphics){
        for(nodes in this.node_info){
            set_source_rgba(this.node_info[nodes]['col']);
            position = get_draw_pos(this.node_info[nodes]['pos'])
            ellipse([position[0], position[1], this.style.node_size, this.style.node_size]);
            fill();
        }
    }
}

function set_pos(node, x, y){
    this.node_info[node]['pos'] = [x, y];
    update();
}

function get_draw_pos(real_pos){
    return [scaler(real_pos[0], 0, 1, 0, this.box_info[2]) - (this.style.node_size * 0.5), scaler(real_pos[1], 0, 1, 0, this.box_info[3]) - (this.style.node_size * 0.5)]
}

function scaler(val, old_min, old_max, new_min, new_max){
    return new_min + (((val - old_min) * (new_max - new_min)) / (old_max - old_min));
}

function draw_bg(){
    with(mgraphics){
        set_source_rgba(this.style.bg_col);
        rectangle([0, 0, this.box_info[2], this.box_info[3]]);
        fill();
    }
};

function onresize(x, y, button, shift){
    this.box_info = get_box_info(this);
    update();
};

function get_box_info(obj){
    // Return the follwing list about the max object box:
    // [x, y, w, h]

    x = obj.box.rect[0];
    y = obj.box.rect[1];
    w = obj.box.rect[2] - obj.box.rect[0];
    h = obj.box.rect[3] - obj.box.rect[1];

    return [x, y, w, h];
};



function onidle(x, y, button, shift){
    idle_process(x, y, button, shift);
    update();
};

function idle_process(x, y, button, shift){
    this.mouseState[0] = x,
    this.mouseState[1] = y,
    this.mouseState[2] = button,
    this.mouseState[3] = shift;
    this.mouseState[6] = false;

    if(this.mouseState[3] == 1){
        this.shiftState = true;
    } else{
        this.shiftState = false;
    }



    for(nodes in this.node_info){
        if(this.node_info[nodes]['write'] == 1){
            new_pos = [scaler(this.mouseState[0], 0, this.box_info[2], 0, 1), scaler(this.mouseState[1], 0, this.box_info[3], 0, 1)]
            this.node_info[nodes]['pos'] = new_pos;
        }
    }
};

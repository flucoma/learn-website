inlets = 1;
outlets = 1;
setinletassist(0, 'Ctrl In');
setoutletassist(0, 'Ctrl Out');

function create_player(num_chans, buf_name, x_pos, y_pos){
    reset();

    pass_in = find_object('pass_in');
    pass_out = find_object('pass_out');
    sel_pass = find_object('sel_pass');
    sync_pass = find_object('sync_pass');
    sig_pass = find_object('sig_pass');


    sig_obj = create_obj(x_pos, y_pos , 'sig~', [1.]);
    groove_obj = create_obj(x_pos, y_pos + 30, 'groove~', [buf_name, num_chans, '@loop', 0]);
    select_obj = create_obj(x_pos, y_pos + 60, 'selector~', [num_chans, 1]);
    
    this.patcher.connect(sig_obj, 0, groove_obj, 0);
    this.patcher.connect(pass_in, 0, groove_obj, 0);
    this.patcher.connect(sig_pass, 0, sig_obj, 0);
    for(i = 0; i < num_chans; i++){
        this.patcher.connect(groove_obj, i, select_obj, i + 1);
    }
    this.patcher.connect(groove_obj, num_chans, sync_pass, 0);
    this.patcher.connect(sel_pass, 0, select_obj, 0);
    this.patcher.connect(select_obj, 0, pass_out, 0);
    outlet(0, 'bang');
};

function find_object(var_name){
    obj = this.patcher.firstobject;
    for(i = 0; i < this.patcher.count; i++){
        if(obj.varname.indexOf(var_name) > -1){
            return obj;
        }
        obj = obj.nextobject;
    }
}

function reset(){
    to_delete = [];
    obj = this.patcher.firstobject;

    for(i = 0; i < this.patcher.count; i++){
        if(obj.varname.indexOf('jscreated') > -1){
            to_delete.push(obj);
        }

        obj = obj.nextobject;
    }

    for(i = 0; i < to_delete.length; i++){
        this.patcher.remove(to_delete[i]);
    }
}

function create_obj(x, y, object, args){
    obj = this.patcher.newdefault(x, y, object, args);
    obj.varname = 'jscreated';

    return obj;
}
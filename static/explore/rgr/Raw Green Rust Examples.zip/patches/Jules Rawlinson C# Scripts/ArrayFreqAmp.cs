﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrayFreqAmp : MonoBehaviour {

	private GameObject go;// ref to parent

	public GameObject prefab;// ref to object for instantiation

	public List<GameObject> arFreqAmp = new List<GameObject>(); // fft particles
	// this is essentially an arrayList - see http://wiki.unity3d.com/index.php/Choosing_the_right_collection_type 

	public bool updateDisplay = true;

	int arLength;

	private float fAmp = 0f;
	private float fFreq = 0f;
	private float fSpecFlat = 0f;
	private float fSpecCent = 0f;
	private float fSensDiss = 0f;

	private Vector4 colVec;
	private Vector3 posVec;
	private Vector3 scaleVec;

	private Color bob;
	private Color alice;

	private Renderer rend;
	private TrailRenderer tr;

	private float r = 0f;
	private float g = 0f;
	private float b = 0f;

	private GameObject newparticle;

	// Use this for initialization
	void Start () {
		go = gameObject;
		arLength = go.GetComponent<OSCReceiver>().nHistory;
		colVec = new Vector4(0f,0f,0f,0f);
		posVec = new Vector3(256f, 50f, 256f);
		scaleVec = new Vector3(0f,0f, 0f);
		for(int i = 0; i <arLength; i++){
		// fft particle object for instantiation
		newparticle = Instantiate(prefab, posVec, Quaternion.identity);
		newparticle.transform.parent = go.transform;
		// fixed scale
		newparticle.transform.localScale = scaleVec;
		// add particle object to List
		newparticle.SetActive(false);
		arFreqAmp.Add(newparticle); 

		r = go.GetComponent<OSCReceiver>().nRed;
		g = go.GetComponent<OSCReceiver>().nGreen;
		b = go.GetComponent<OSCReceiver>().nBlue;
	}
	}

	void FixedUpdate() {
		for(int i = 0; i <arLength; i++){
			arFreqAmp[i].SetActive(updateDisplay);
			if(updateDisplay){
			fAmp = go.GetComponent<OSCReceiver>().arLoudness[i]; // get current fft values from OSCReceiver
			fFreq = go.GetComponent<OSCReceiver>().arFrequency[i];
			fSpecFlat = go.GetComponent<OSCReceiver>().arSpecFlat[i];
			fSpecCent = go.GetComponent<OSCReceiver>().arSpecCent[i];
			fSensDiss = go.GetComponent<OSCReceiver>().arSensDiss[i];
			if(fFreq == 0) fFreq = 1;
			fFreq = ((12f*Mathf.Log(fFreq/440f,2)) + 69) / 128f;
			if(float.IsInfinity(fFreq)) fFreq = 0f;
			if(float.IsNaN(fFreq)) fFreq = 0f;
			if(fSpecCent == 0) fSpecCent = 1;
			fSpecCent = ((12f*Mathf.Log(fSpecCent/440f,2)) + 69) / 128f;
			if(float.IsInfinity(fSpecCent)) fSpecCent = 0f;
			if(arFreqAmp[i] != null){
			posVec.Set(fFreq*512f, fAmp * 4f, fSpecFlat*512f);
			arFreqAmp[i].transform.position = posVec;
			//transform scale
			scaleVec.Set(fAmp,fAmp,fAmp);
			arFreqAmp[i].transform.localScale = scaleVec;
			// colour
			//alice =  Color.HSVToRGB(fFreq, 1, 1);
			//bob = new Vector4(alice[0], alice[1], alice[2], fSpecFlat * 0.3f);
			colVec.Set(r, g, b, fAmp * 0.005f);
			bob = colVec;
			rend = arFreqAmp[i].GetComponent<Renderer>();
			rend.material.color = bob;
			// trail
			tr = arFreqAmp[i].GetComponent<TrailRenderer>();
			tr.startColor = bob;
			rend.material.SetColor ("_EmissionColor", bob);
			}
			}
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OSCReceiver : MonoBehaviour {

	// references to other objects - set in inspector

	public OSC osc;// reference to OSC script

	// raw vals
	public float fLoudnessRaw;
	public float fFrequencyRaw;
    public float fConfidenceRaw;
	public float fSpecFlatnessRaw;
	public float fSpecCentroidRaw;
	public float fSensDissonanceRaw;

	//cooked vals - smoothed with SmoothDamp

	public float fLoudness;
	public float fFrequency;
    public float fConfidence;
    public float fSpecFlatness;
	public float fSpecCentroid;
	public float fSensDissonance;

	// not damped
	public float fOnset;


	// arrays
	public float[] arLoudness;
	public float[] arFrequency;
    public float[] arConfidence;
	public float[] arSpecFlat;
	public float[] arSpecCent;
	public float[] arSensDiss;
	public float[] arOnsets;

	public int numFFTs = 128;
	public int numMELs = 25;
	public int numBARKs = 24;

	public float[] fftVals;
	public float[] melVals;
	public float[] barkVals;
	public float[] barkValsOld;

	public int nHistory = 128;

	public string szOscMessPrefix = "";

	public float nRed;
	public float nGreen;
	public float nBlue;

	// damping vals
	public float fftDampingVal;

	private float fv;
	private float vel = 0f;// use in dampsmooths functions
	private float velFFT = 0f;// use in dampsmooths functions
	private float velBark = 0f;


	// sender
	OscMessage message;

	private void Awake () {
		// keep rendering when focus is elsewhere
		if (Application.isEditor)
			Application.runInBackground = true;
	}

	// Use this for initialization
	private void Start () {
		//osc.SetAllMessageHandler(OnReceive);
		osc.SetAddressHandler(szOscMessPrefix + "/melArray", OnReceive);
		osc.SetAddressHandler(szOscMessPrefix + "/fftArray" , OnReceive);
		osc.SetAddressHandler(szOscMessPrefix + "/barkArray" , OnReceive);
		osc.SetAddressHandler(szOscMessPrefix + "/loudness", OnReceive);
		osc.SetAddressHandler(szOscMessPrefix + "/frequency", OnReceive);
		osc.SetAddressHandler(szOscMessPrefix + "/spectralFlatness", OnReceive);
		osc.SetAddressHandler(szOscMessPrefix + "/spectralCentroid", OnReceive);
		osc.SetAddressHandler(szOscMessPrefix+ "/sensoryDissonance", OnReceive);
		osc.SetAddressHandler(szOscMessPrefix + "/onsets", OnReceive);
        osc.SetAddressHandler(szOscMessPrefix + "/packet", OnReceive);

        melVals = new float[numMELs];
		fftVals = new float[numFFTs];
		barkVals = new float[numBARKs];
		barkValsOld = new float[numBARKs];

		for(int i = 0; i < numBARKs; i++){
			barkVals[i] = 0f;
			barkValsOld[i] = 0f;
		}

		// loudness
		arLoudness = new float[nHistory];
		for(int i = 0; i < arLoudness.Length; i++){
			arLoudness[i] = 0f;
		}

		// frequency
		arFrequency = new float[nHistory];
		for(int i = 0; i < arFrequency.Length; i++){
			arFrequency[i] = 0f;
		}

        // confidence
        arConfidence = new float[nHistory];
        for (int i = 0; i < arConfidence.Length; i++)
        {
            arConfidence[i] = 0f;
        }

        // specFlat
        arSpecFlat = new float[nHistory];
		for(int i = 0; i < arSpecFlat.Length; i++){
			arSpecFlat[i] = 0f;
		}

		// specCent
		arSpecCent = new float[nHistory];
		for(int i = 0; i < arSpecCent.Length; i++){
			arSpecCent[i] = 0f;
		}

		// specFlat
		arSensDiss = new float[nHistory];
		for(int i = 0; i < arSensDiss.Length; i++){
			arSensDiss[i] = 0f;
		}

		// onsets
		arOnsets = new float[nHistory];
		for(int i = 0; i < arOnsets.Length; i++){
			arOnsets[i] = 0f;
		}

		//sender
		message = new OscMessage();

	}

	// Function that receives the message
	void OnReceive(OscMessage message) {
		//Debug.Log("message = " + message);

		//http://doc.sccode.org/Classes/MFCC.html
		if( message.address == szOscMessPrefix + "/melArray" ) {
			// accessing the first float in the list
			//Debug.Log(message.GetFloat(0));
			for(int i = 0; i < numMELs; i++) {

				// where do we want to the the normalising?

				// value remapping - low2 + (value - low1) * (high2 - low2) / (high1 - low1)
				// found here : https://stackoverflow.com/questions/3451553/value-remapping
				// in processing - barkvals[0] = map(fs, -96.0, 30, 0, 10);


				fv = message.GetFloat(i);
				// remap
				fv = fv * 300f;
				// clamp
				fv = Mathf.Clamp(fv, 0f, 300f);
				// exp
				//fv = Mathf.Pow(fv,3f);

				// damping
				fv = Mathf.SmoothDamp(melVals[i], fv, ref vel, 0.1f);

				melVals[i] = fv;
				//melvalues = melvalues + " " + newval;
			}
				//Debug.Log("mel" + melvalues);// list of all vals
		}

		// FFT
		if( message.address == szOscMessPrefix + "/fftArray" ) {
			// accessing the first float in the list
			//Debug.Log(message.GetFloat(0));

			for(int i = 0; i < numFFTs; i++) {

				fv = message.GetFloat(i);

				// remap
				fv = fv * 200f;

				// damping
				fv = Mathf.SmoothDamp(fftVals[i], fv, ref velFFT, fftDampingVal);// damping - higher number = slower response


				fftVals[i] = fv;
			}

		}

		// BARK
		if( message.address == szOscMessPrefix + "/barkArray" ) {
			// accessing the first float in the list
			//Debug.Log(message.GetFloat(0));
			barkVals.CopyTo(barkValsOld,0);

			for(int i = 0; i < numBARKs; i++) {

				fv = message.GetFloat(i);

				fv = Mathf.SmoothDamp(barkVals[i], fv, ref velBark, 0.00f);// damping - higher number = slower response

				barkVals[i] = fv;
			}

		}

		//http://doc.sccode.org/Classes/Loudness.html
		if( message.address == szOscMessPrefix + "/loudness" ) {
			fv = message.GetFloat(0);
            fv = Mathf.Clamp(fv, 0f, 100f);
            fLoudnessRaw = fv;
			fLoudness = Mathf.SmoothDamp(fLoudness, fv, ref vel, 0.002f);
			//update array
			for(int i = arLoudness.Length - 1; i > 0; i--){
				arLoudness[i] = arLoudness[i - 1];
			}
			// update first pos in array with most recent value
			arLoudness[0] = fLoudness;


		}

		//http://doc.sccode.org/Classes/Pitch.html
		if( message.address == szOscMessPrefix + "/frequency" ) {
			fv = message.GetFloat(0);
			fv = Mathf.Clamp(fv, 0f, 22000f);
			fFrequencyRaw = fv;
			fFrequency = Mathf.SmoothDamp(fFrequency, fv, ref vel, 0.02f);
			//update array
			for(int i = arFrequency.Length - 1; i > 0; i--){
				arFrequency[i] = arFrequency[i - 1];
			}
			// update first pos in array with most recent value
			arFrequency[0] = fFrequency;
            //
            // now confidence 22.06.21
            //
            fv = message.GetFloat(1);
            fv = Mathf.Clamp(fv, 0f, 1f);
            fConfidenceRaw = fv;
            fConfidence = fv;
            //update array
            for (int i = arConfidence.Length - 1; i > 0; i--)
            {
                arConfidence[i] = arConfidence[i - 1];
            }
            // update first pos in array with most recent value
            arConfidence[0] = fConfidence;
        }

		//http://doc.sccode.org/Classes/SpecFlatness.html
		if( message.address == szOscMessPrefix + "/spectralFlatness" ) {
			fv = message.GetFloat(0);
			fv = Mathf.Clamp(fv, 0f, 1f);
			fSpecFlatnessRaw = fv;
			fSpecFlatness = Mathf.SmoothDamp(fSpecFlatness, fv, ref vel, 0.002f);
			fSpecFlatness = Mathf.Clamp(fSpecFlatness, 0f, 1f);
			//update array
			for(int i = arSpecCent.Length - 1; i > 0; i--){
				arSpecFlat[i] = arSpecFlat[i - 1];
			}
			// update first pos in array with most recent value
			arSpecFlat[0] = fSpecFlatness;
			//Debug.Log("Flatness " + fSpecFlatness);
		}

		//http://doc.sccode.org/Classes/SpecCentroid.html
		if( message.address == szOscMessPrefix + "/spectralCentroid" ) {
			fv = message.GetFloat(0);
			fv = Mathf.Clamp(fv, 0f, 22000f);
			fSpecCentroidRaw = fv;
			fSpecCentroid = Mathf.SmoothDamp(fSpecCentroid, fv, ref vel, 0.02f);
			//update array
			for(int i = arSpecCent.Length - 1; i > 0; i--){
				arSpecCent[i] = arSpecCent[i - 1];
			}
			// update first pos in array with most recent value
			arSpecCent[0] = fSpecCentroid;
		}

        // basics as packet

        if (message.address == szOscMessPrefix + "/packet")
        {
            //loudness
            fv = message.GetFloat(0);
            fv = Mathf.Clamp(fv, 0f, 100f);
            fLoudnessRaw = fv;
            fLoudness = Mathf.SmoothDamp(fLoudness, fv, ref vel, 0.002f);
            //update array
            for (int i = arLoudness.Length - 1; i > 0; i--)
            {
                arLoudness[i] = arLoudness[i - 1];
            }
            // update first pos in array with most recent value
            arLoudness[0] = fLoudness;

            //pitch
            fv = message.GetFloat(1);
            fv = Mathf.Clamp(fv, 0f, 22000f);
            fFrequencyRaw = fv;
            fFrequency = Mathf.SmoothDamp(fFrequency, fv, ref vel, 0.02f);
            //update array
            for (int i = arFrequency.Length - 1; i > 0; i--)
            {
                arFrequency[i] = arFrequency[i - 1];
            }
            // update first pos in array with most recent value
            arFrequency[0] = fFrequency;
            
            // confidence
            fv = message.GetFloat(2);
            fv = Mathf.Clamp(fv, 0f, 1f);
            fConfidenceRaw = fv;
            fConfidence = fv;
            //update array
            for (int i = arConfidence.Length - 1; i > 0; i--)
            {
                arConfidence[i] = arConfidence[i - 1];
            }
            // update first pos in array with most recent value
            arConfidence[0] = fConfidence;

            //spec centroid
            fv = message.GetFloat(3);
            fv = Mathf.Clamp(fv, 0f, 22000f);
            fSpecCentroidRaw = fv;
            fSpecCentroid = Mathf.SmoothDamp(fSpecCentroid, fv, ref vel, 0.02f);
            //update array
            for (int i = arSpecCent.Length - 1; i > 0; i--)
            {
                arSpecCent[i] = arSpecCent[i - 1];
            }
            // update first pos in array with most recent value
            arSpecCent[0] = fSpecCentroid;

            //spec_flatness
            fv = message.GetFloat(4);
            fv = Mathf.Clamp(fv, 0f, 1f);
            fSpecFlatnessRaw = fv;
            fSpecFlatness = Mathf.SmoothDamp(fSpecFlatness, fv, ref vel, 0.002f);
            fSpecFlatness = Mathf.Clamp(fSpecFlatness, 0f, 1f);
            //update array
            for (int i = arSpecCent.Length - 1; i > 0; i--)
            {
                arSpecFlat[i] = arSpecFlat[i - 1];
            }
            // update first pos in array with most recent value
            arSpecFlat[0] = fSpecFlatness;

            //onset
            fv = message.GetFloat(5);
            fOnset = fv;
            //update array
            for (int i = arOnsets.Length - 1; i > 0; i--)
            {
                arOnsets[i] = arOnsets[i - 1];
            }
            // update first pos in array with most recent value
            arOnsets[0] = fv;
        }

        // http://doc.sccode.org/Classes/SensoryDissonance.html
        if ( message.address == szOscMessPrefix+ "/sensoryDissonance" ) {
			fv = message.GetFloat(0);
			if (fv < 0) fv = 0;
			fSensDissonanceRaw = fv;
			fSensDissonance = Mathf.SmoothDamp(fSensDissonance, fv, ref vel, 0.02f);
			//update array
			for(int i = arSpecCent.Length - 1; i > 0; i--){
				arSensDiss[i] = arSensDiss[i - 1];
			}
			// update first pos in array with most recent value
			arSensDiss[0] = fSensDissonance;
		}


		// http://doc.sccode.org/Classes/Onsets.html
		if( message.address == szOscMessPrefix + "/onsets" ) {
			fv = message.GetFloat(0);
			fOnset = fv;
			//update array
			for(int i = arOnsets.Length - 1; i > 0; i--){
				arOnsets[i] = arOnsets[i - 1];
			}
			// update first pos in array with most recent value
			arOnsets[0] = fv;

		}

		// http://doc.sccode.org/Classes/Onsets.html
		if( message.address == szOscMessPrefix + "/chromagramArray" ) {
			Debug.Log(message);

		}




	}

	// Update is called once per frame
	void Update () {
		
	}

	public void SendMessage(string address, float val){
		message.values.Clear();
		message.address = szOscMessPrefix + address;
		message.values.Add(val);
		osc.Send(message);
	}
}

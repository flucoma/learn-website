﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleCreator : MonoBehaviour {

	private GameObject go;// ref to parent

	public GameObject prefab;// ref to object for instantiation

	GameObject newparticle;// fft particle object for instantiation

	public Texture[] textures; // array of textures set in inspector

	public List<GameObject> particles = new List<GameObject>(); // fft particles
	// this is essentially an arrayList - see http://wiki.unity3d.com/index.php/Choosing_the_right_collection_type 

	Camera m_MainCamera;

	float width = 511f;

	public bool fixedHeight = false;
	public bool textureMode = false;
	public bool updateDisplay = true;
	public bool colourMode = false;


	private Color bob;
	private Renderer rend;
	private LineRenderer lineRender;
	private TrailRenderer tr;

	private Vector4 colVec;
	private Vector3 posVec;
	private Vector3 scaleVec;
	private Vector3 rotVec;

	float r;
	float g;
	float b;

	float fAmp = 0f;
	float fFreq = 0f;
    float fConf = 0f;
	float fSpecFlat = 0f;
	float freqConv = 0f;
	float ypos = 0f;

	int nTex = 0;

	float speed = 0f;


	// Use this for initialization
	void Start () {
		go = gameObject;
		r = go.GetComponent<OSCReceiver>().nRed;
		g = go.GetComponent<OSCReceiver>().nGreen;
		b = go.GetComponent<OSCReceiver>().nBlue;
		colVec = new Vector4(r, g, b, 0.5f);
		posVec = new Vector3(0f,0f,0f);
		scaleVec = new Vector3(0.2f, 0.2f, 0f);
		rotVec = new Vector3(0f, 0f, 0f);

		m_MainCamera = Camera.main;

		for(int i = 0; i < 512; i++){
			// instantiate Cube & set start position
			newparticle = Instantiate(prefab, posVec, Quaternion.identity);
			newparticle.transform.parent = go.transform;
			//update scale
			newparticle.transform.localScale = scaleVec;
			// set inactive
			newparticle.SetActive(false);
			// add particle object to List
			particles.Add(newparticle);
		}
	}
	
	// Update is called once per frame
	void Update () {


		fAmp = go.GetComponent<OSCReceiver>().fLoudness; // get current fft values from OSCReceiver


		//Debug.Log(fAmp);

		if(fAmp > 0 && updateDisplay){

        fConf = go.GetComponent<OSCReceiver>().fConfidence;
            if (fConf > 0.5)
            {
            fFreq = go.GetComponent<OSCReceiver>().fFrequency;
            }
            else
            {
            fFreq = go.GetComponent<OSCReceiver>().fSpecCentroid;
            }
        
		fSpecFlat = go.GetComponent<OSCReceiver>().fSpecFlatness;
		
		freqConv = ((12f*Mathf.Log(fFreq/440f,2)) + 69) / 136f;
		if(float.IsNaN(freqConv)) freqConv = 0f;
		// (((log10 (($f1 / 440.))) / (log10 (2))) * 12.) + 69
		//Debug.Log("freq = " + fFreq + "conv = " + freqConv);

		// instantiate Cube & set start position
		ypos = fAmp*4;
		scaleVec.Set(fAmp * 0.3f, fAmp * 0.3f, 0f);
		rotVec.Set(0f,0f,0f);
		
		if(m_MainCamera.GetComponent<CameraController>().camMode == 4){
				ypos = 0f;
				//scaleVec.Set(fAmp * 0.2f, 0.2f, fAmp * 0.2f);
				rotVec.Set(90f,90f,0f);
			}

		if(fixedHeight && m_MainCamera.GetComponent<CameraController>().camMode != 4) ypos = 75f;

		newparticle = nextFreeParticle();
		
		posVec.Set(freqConv * width, ypos, 0f);
		newparticle.transform.position = posVec;
		//update scale
		//fftCube.transform.localScale = new Vector3(10f, fv, 20f);
		//newparticle.transform.eulerAngles = new Vector3(270, 0, 0);
		// fixed scale
		newparticle.transform.localScale = scaleVec;
		newparticle.transform.eulerAngles = rotVec;


		//update Speedvar
		newparticle.GetComponent<SpeedVar>().speedvar = 5.0f;

		// color?
		//bob = Color.HSVToRGB((fAmp/20f),1f,1f);
		bob = colVec;
		if(colourMode)bob = Color.HSVToRGB(freqConv,1f,1f);
		rend = newparticle.GetComponent<Renderer>();
		rend.material.color = bob;

		tr = newparticle.GetComponent<TrailRenderer>();
		tr.startColor = bob;
		rend.material.SetColor ("_EmissionColor", bob);

		// clamping
		nTex = Mathf.FloorToInt((fSpecFlat * 10f) + 0.1f);
		if(nTex < 0) nTex = 0;
		if(nTex > textures.Length - 1) nTex = textures.Length - 1;
		
		if(textureMode) rend.material.mainTexture = textures[nTex];

		// add colour to attached script
		newparticle.GetComponent<ParticleGarbageCollision>().nRed = r;
		newparticle.GetComponent<ParticleGarbageCollision>().nGreen = g;
		newparticle.GetComponent<ParticleGarbageCollision>().nBlue = b;

		newparticle.SetActive(true);
		}


		int numcubes = particles.Count;// how many current fft particles?
		for(int i = numcubes - 1; i >= 0; i--){
			if(particles[i].activeInHierarchy){
			speed = particles[i].GetComponent<SpeedVar>().speedvar;
			posVec.Set(particles[i].transform.position.x,
					particles[i].transform.position.y,
					particles[i].transform.position.z + speed);
			particles[i].transform.position = posVec;
													// this number affects 'percieved speed' but also history
			if(particles[i].transform.position.z > 512f) {
			particles[i].SetActive(false);
			}
		}
		}		

	
	}

	GameObject nextFreeParticle(){
		for(int i = 0; i < particles.Count; i++){
			if(!particles[i].activeInHierarchy){
				return particles[i];
			}
		}
		return particles[0];
	}

}

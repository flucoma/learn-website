function create_abstractions(num_abs, offset){
    reset();

    this_box = get_box_info(this);

    for(i = 0; i < num_abs; i++){
        abs = create_obj(this_box[0], this_box[1] + 25 + (25 * i), 'note_filter', [i + offset]);
    };

    outlet(0, 'bang');
};

function reset(){
    to_delete = [];
    obj = this.patcher.firstobject;

    for(i = 0; i < this.patcher.count; i++){
        if(obj.varname.indexOf('jscreated') > -1){
            to_delete.push(obj);
        };

        obj = obj.nextobject;
    };

    for(i = 0; i < to_delete.length; i++){
        this.patcher.remove(to_delete[i]);
    };
};

function create_obj(x, y, object, args){
    obj = this.patcher.newdefault(x, y, object, args);
    obj.varname = 'jscreated';

    return obj;
};

function get_box_info(obj){
    x = obj.box.rect[0];
    y = obj.box.rect[1];
    w = obj.box.rect[2] - obj.box.rect[0];
    h = obj.box.rect[3] - obj.box.rect[1];

    return [x, y, w, h];
};
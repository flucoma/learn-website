inlets = 1;
outlets = 2;

this.dur_buffer = 0;

this.params = {
    lowest_note : 48,
    highest_note : 72,
    num_notes : 25,
    lowest_velocity : 20,
    highest_velocity : 120,
    num_dynamics : 3,
    velocity_step : 50,
    shortest_dur : 100,
    longest_dur : 2000,
    num_durs : 2,
    dur_step : 1900
};

function calculate_sequence(){
    outlet(0, 'clear');
    count = 0;
    full_dur = 0;

    for(i = 0; i < this.params.num_notes; i++){
        this_note = this.params.lowest_note + i
        for(j = 0; j < this.params.num_dynamics; j++){
            this_velocity = this.params.lowest_velocity + (this.params.velocity_step * j);
            for(k = 0; k < this.params.num_durs; k++){
                this_dur = this.params.shortest_dur + (this.params.dur_step * k);
                count++
                full_dur = full_dur + this_dur + this.dur_buffer;
                entry = {
                    note : this_note,
                    velocity : this_velocity,
                    duration : this_dur,
                    index : count,
                    name : String(this_note) + '_' + String(this_velocity) + '_' + String(this_dur),
                    filename : String(this_note) + '_' + String(this_velocity) + '_' + String(this_dur) + '.wav'
                };
                for(item in entry){
                    outlet(0, 'replace ' + entry["name"] + '::' + item + ' ' + String(entry[item]));
                };
            };
        };
    };

    outlet(1, 'num_entries ' + String(count));
    outlet(1, 'full_dur ' + String(full_dur));
};

function set_params(ln, hn, lv, hv, nd, sd, ld, ndu){
    this.params.lowest_note = ln;
    this.params.highest_note = hn;
    this.params.num_notes = (hn - ln) + 1;
    this.params.lowest_velocity = lv;
    this.params.highest_velocity = hv;
    this.params.num_dynamics = nd;
    this.params.shortest_dur = sd;
    this.params.longest_dur = ld;
    this.params.num_durs = ndu;

    this.params.velocity_step = (hv - lv) / (nd - 1);
    this.params.dur_step = (ld - sd) / (ndu - 1);

    calculate_sequence();
};
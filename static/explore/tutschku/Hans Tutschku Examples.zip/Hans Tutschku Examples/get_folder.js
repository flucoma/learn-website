function get_folder(path){
    path_split = path.split('/');
    out_string = ''

    for(i = 0; i < path_split.length - 1; i++){
        out_string = out_string + path_split[i] + '/';
    };

    outlet(0, out_string);
};
col_wid = 150;
button_hei = 12;
x_padding = 10;
comment_height = 29;

final_button_wid = 50;

text_col = [0.329, 0.329, 0.329, 1.000];
default_col = [0.475, 0.592, 0.608, 1.000];
panel_border_col = [0., 0., 0., 1.];
panel_bg_fill = [0.200, 0.200, 0.200, 0.110];
group_cols = [
    [0.475, 0.592, 0.608, 1.000],
    [0.145, 0.208, 0.357, 1.000],
    [0.294, 0.416, 0.718, 1.000],
    [0.439, 0.624, 0.075, 1.000],
    [0.588, 0.827, 0.431, 1.000],
    [0.733, 0.035, 0.788, 1.000],
    [0.882, 0.243, 0.149, 1.000],
    [0.027, 0.451, 0.506, 1.000],
    [0.663, 0.412, 0.224, 1.000],
    [0.667, 0.537, 0.847, 1.000],
    [0.384, 0.384, 0.384, 1.000]
];

function build(dict1, dict2, dict3, x, y, final_comps){

    reset();


    var dict_1 = new Dict(dict1);
    var dict_2 = new Dict(dict2);
    var dict_3 = new Dict(dict3);

    comp_pass_obj = find_object('100_COMP_PASS');
    hover_pass_obj = find_object('HOVER_PASS');
    router_args = [];
    for(i = 0; i < final_comps; i++){
        router_args.push(i+1);
    }
    hover_pass_router = create_obj(945., 565., 'route', router_args);
    this.patcher.connect(hover_pass_obj, 0, hover_pass_router, 0);

    dict_1_mm = get_min_max(dict_1);
    dict_2_mm = get_min_max(dict_2);
    dict_3_mm = get_min_max_2(dict_3);

    first_panel = create_obj(x, y, 'panel');
    first_panel.message('patching_rect', [x, y, button_hei * dict_1.getkeys().length, col_wid]);
    first_panel.message('rounded', 0);
    first_panel.message('border', 1);
    first_panel.message('bordercolor', panel_border_col);
    first_panel.message('bgfillcolor', panel_bg_fill);
    first_panel.message('presentation', 1);

    first_title = create_obj(x, y + (col_wid - comment_height), 'comment');
    first_title.message('patching_rect', [x , y + (col_wid - comment_height), button_hei * dict_1.getkeys().length, comment_height]);
    first_title.message('fontsize', 20);
    first_title.message('set', '100 components pitch analysis (0-' + String(dict_1_mm[1]) + ' Hz).');
    first_title.message('fontface', 2);
    first_title.message('textcolor', text_col);
    first_title.message('presentation', 1);
    
    for(i = 0; i < dict_1.getkeys().length; i++){

        this_val = dict_1.get(dict_1.getkeys()[i]);
        this_wid = min_max_scaler(this_val, 0, dict_1_mm[1], 0, col_wid);

        this_button = create_obj(x + (i * button_hei), y , 'textbutton');
        this_button.message('patching_rect', [x + (i * button_hei), y , button_hei, this_wid]);
        this_button.message('text', String(i + 1));
        this_button.message('textoncolor', [0., 0., 0., 0.]);
        this_button.message('bgcolor', default_col);
        this_button.message('hint', 'Component ' + String(i + 1) + ': ' + String(this_val) + ' Hz.');
        this_button.message('presentation', 1);

        this.patcher.hiddenconnect(this_button, 1, comp_pass_obj, 0);
    }

    
    second_panel = create_obj(x , y + col_wid + x_padding, 'panel');
    second_panel.message('patching_rect', [x , y + col_wid + x_padding, button_hei * dict_2.getkeys().length ,col_wid ]);
    second_panel.message('rounded', 0);
    second_panel.message('border', 1);
    second_panel.message('bordercolor', panel_border_col);
    second_panel.message('bgfillcolor', panel_bg_fill);
    second_panel.message('presentation', 1);

    second_title = create_obj(x, y + (col_wid - comment_height) + col_wid + x_padding, 'comment');
    second_title.message('patching_rect', [x , y + (col_wid - comment_height) + col_wid + x_padding, button_hei * dict_1.getkeys().length, comment_height]);
    second_title.message('fontsize', 20);
    second_title.message('set', '100 components grouping.');
    second_title.message('fontface', 2);
    second_title.message('textcolor', text_col);
    second_title.message('presentation', 1);

    group_col_map = [];

    for(i = 0; i < dict_2.getkeys().length; i++){

        this_val = dict_2.get(dict_2.getkeys()[i]);
        this_wid = min_max_scaler(this_val, 0, dict_2_mm[1], 0, col_wid);

        this_col = [];
        if(this_val > final_comps){
            this_col = group_cols[final_comps - 1];
            //group_col_map.push([i, 10]);
        }else{
            this_col = group_cols[this_val - 1];
            //group_col_map.push([i, this_val - 1]);
        }

        this_button = create_obj(x + (i * button_hei), y  + col_wid + x_padding, 'textbutton');
        this_button.message('patching_rect', [x + (i * button_hei), y  + col_wid + x_padding, button_hei, this_wid ]);
        this_button.message('text', String(i + 1));
        this_button.message('textoncolor', [0., 0., 0., 0.]);
        this_button.message('bgcolor', this_col);
        this_button.message('hint', 'Component ' + String(i + 1) + '. Group: ' + String(this_val) + '.');
        this_button.message('presentation', 1);

        this.patcher.hiddenconnect(this_button, 1, comp_pass_obj, 0);

        this_group = this_val;
        /*
        if(this_val > final_comps){
            this_group = final_comps;
        }else{
            this_group = this_val;
        }
        */

        hover_button_1 = create_obj(x + (i * button_hei), y , 'textbutton');
        hover_button_1.message('patching_rect', [x + (i * button_hei), y , button_hei, col_wid]);
        hover_button_1.message('text', '');
        hover_button_1.message('bgcolor', [1., 0., 0., 0.]);
        hover_button_1.message('presentation', 1);

        hover_button_2 = create_obj(x + (i * button_hei), y  + col_wid + x_padding, 'textbutton');
        hover_button_2.message('patching_rect', [x + (i * button_hei), y  + col_wid + x_padding, button_hei, col_wid]);
        hover_button_2.message('text', '');
        hover_button_2.message('bgcolor', [1., 0., 0., 0.]);
        hover_button_2.message('presentation', 1);

        this.patcher.hiddenconnect(hover_pass_router, this_group -1, hover_button_1, 0);
        this.patcher.hiddenconnect(hover_pass_router, this_group -1, hover_button_2, 0);
    }

    current_offset = col_wid + x_padding +  col_wid + x_padding;

    third_panel = create_obj(x , y + current_offset, 'panel');
    third_panel.message('patching_rect', [x , y + current_offset, final_button_wid * dict_3.getkeys().length ,col_wid ]);
    third_panel.message('rounded', 0);
    third_panel.message('border', 1);
    third_panel.message('bordercolor', panel_border_col);
    third_panel.message('bgfillcolor', panel_bg_fill);
    third_panel.message('presentation', 1);

    final_play_pass_obj = find_object('FINAL_PLAY_PASS');
    
    

    final_title = create_obj(x, y + (col_wid - comment_height) + current_offset, 'comment');
    final_title.message('patching_rect', [x , y + (col_wid - comment_height) + current_offset, button_hei * dict_1.getkeys().length, comment_height]);
    final_title.message('fontsize', 20);
    final_title.message('set', '2nd NMF Results. (' + String(dict_3_mm[0]) + '-' + String(dict_3_mm[1]) + ' Hz).');
    final_title.message('fontface', 2);
    final_title.message('textcolor', text_col);
    final_title.message('presentation', 1);
    
    for(i = 0; i < dict_3.getkeys().length; i++){

        

        this_val = dict_3.get(dict_3.getkeys()[i] + '::mean_freq');
        this_wid = min_max_scaler(this_val, 0, dict_3_mm[1], 0, col_wid);
        this_group = dict_3.get(dict_3.getkeys()[i] + '::group');

        if(this_group > final_comps){
            this_group = final_comps;
        }


        this_col = group_cols[this_group -1];
        

        this_button = create_obj(x + (i * button_hei), y + current_offset, 'textbutton');
        this_button.message('patching_rect', [x + (i * final_button_wid), y + current_offset, final_button_wid, this_wid]);
        this_button.message('text', String(this_group));
        this_button.message('textoncolor', [0., 0., 0., 0.]);
        this_button.message('bgcolor', this_col);
        this_button.message('hint', 'Group ' + String(this_group) + ': Mean freq.: ' + String(this_val) + ' Hz.');
        this_button.message('presentation', 1);

        route_obj = create_obj(x + (i * button_hei), y + current_offset + 20, 'prepend', [this_group]);

        this.patcher.hiddenconnect(this_button, 1, final_play_pass_obj, 0);
        this.patcher.hiddenconnect(this_button, 2, route_obj, 0);
        this.patcher.hiddenconnect(route_obj, 0, hover_pass_obj, 0);

    }


    



}

function get_min_max(dic){

    keys = dic.getkeys();

    current_min = dic.get(keys[0]);
    current_max = dic.get(keys[0]);

    for(i = 0; i < keys.length; i++){

        if(dic.get(keys[i]) < current_min){
            current_min = dic.get(keys[i]);
        }
        if(dic.get(keys[i]) > current_max){
            current_max = dic.get(keys[i]);
        }
    }

    return [current_min, current_max];
}

function get_min_max_2(dic){

    keys = dic.getkeys();

    current_min = dic.get(keys[0] + '::mean_freq');
    current_max = dic.get(keys[0] + '::mean_freq');

    for(i = 0; i < keys.length; i++){

        if(dic.get(keys[i] + '::mean_freq') < current_min){
            current_min = dic.get(keys[i] + '::mean_freq');
        }
        if(dic.get(keys[i] + '::mean_freq') > current_max){
            current_max = dic.get(keys[i] + '::mean_freq');
        }
    }

    return [current_min, current_max];
}

function reset(){
    to_delete = [];
    obj = this.patcher.firstobject;

    for(i = 0; i < this.patcher.count; i++){
        if(obj.varname.indexOf('jscreated') > -1){
            to_delete.push(obj);
        }

        obj = obj.nextobject;
    }

    for(i = 0; i < to_delete.length; i++){
        this.patcher.remove(to_delete[i]);
    }
}

function create_obj(x, y, object, args){
    obj = this.patcher.newdefault(x, y, object, args);
    obj.varname = 'jscreated';

    return obj;
}

function min_max_scaler(val, oldMin, oldMax, newMin, newMax){
    return newMin + (((val - oldMin) * (newMax - newMin)) / (oldMax - oldMin));
}

function find_object(var_name){
    obj = this.patcher.firstobject;
    for(i = 0; i < this.patcher.count; i++){
        if(obj.varname.indexOf(var_name) > -1){
            return obj;
        }
        obj = obj.nextobject;
    }
}
function create_player(buf_name, num_chans, x, y){

    reset();

    pass_obj = find_object('PLAYER_PASS');
    pass_out_obj = find_object('PASS_OUT');

    play_obj = create_obj(x, y, 'play~', [buf_name, num_chans]);
    select_obj = create_obj(x, y + 30, 'selector~', [num_chans, 0]);

    this.patcher.connect(pass_obj, 0, play_obj, 0);
    this.patcher.connect(pass_obj, 1, select_obj, 0);
    this.patcher.connect(select_obj, 0, pass_out_obj, 0);

    for(i = 0; i < num_chans; i++){

        this.patcher.connect(play_obj, i, select_obj, i+ 1);

    }

}

function find_object(var_name){
    obj = this.patcher.firstobject;
    for(i = 0; i < this.patcher.count; i++){
        if(obj.varname.indexOf(var_name) > -1){
            return obj;
        }
        obj = obj.nextobject;
    }
}

function reset(){
    to_delete = [];
    obj = this.patcher.firstobject;

    for(i = 0; i < this.patcher.count; i++){
        if(obj.varname.indexOf('jscreated') > -1){
            to_delete.push(obj);
        }

        obj = obj.nextobject;
    }

    for(i = 0; i < to_delete.length; i++){
        this.patcher.remove(to_delete[i]);
    }
}

function create_obj(x, y, object, args){
    obj = this.patcher.newdefault(x, y, object, args);
    obj.varname = 'jscreated';

    return obj;
}
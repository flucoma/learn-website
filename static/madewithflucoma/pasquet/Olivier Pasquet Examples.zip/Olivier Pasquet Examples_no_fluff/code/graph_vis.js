mgraphics.init();
inlets = 1;
outlets = 0;
setinletassist(0, 'Ctrl In');

dict_name = '';
mode = 0;
allow_draw = false;


default_col = [1., 0., 0., 1.];

function draw_data(data_dict, set_mode){

    mode = set_mode;
    allow_draw = true;
    dict_name = data_dict;
    mgraphics.redraw();

}

function paint(){

    function get_box_info(obj)
    {
        // Return the follwing list about the max object box:
        // [x, y, w, h]

        x = obj.box.rect[0];
        y = obj.box.rect[1];
        w = obj.box.rect[2] - obj.box.rect[0];
        h = obj.box.rect[3] - obj.box.rect[1];

        return [x, y, w, h];
    };
    boxInfo = get_box_info(this);

    function get_min_max(dic){

        keys = dic.getkeys();

        current_min = dic.get(keys[0]);
        current_max = dic.get(keys[0]);

        for(i = 0; i < keys.length; i++){

            if(dic.get(keys[i]) < current_min){
                current_min = dic.get(keys[i]);
            }
            if(dic.get(keys[i]) > current_max){
                current_max = dic.get(keys[i]);
            }
        }

        return [current_min, current_max];
    }

    function get_draw_data(dic, minmax, binfo){
        
        keys = dic.getkeys();

        return_list = [];
        hei = binfo[3] / keys.length;

        for(i = 0; i < keys.length; i++){


            x_pos = 0;
            y_pos = i * hei;
            wid = min_max_scaler(dic.get(keys[i]), 0, minmax[1], 0, binfo[2]);

            return_list.push([x_pos, y_pos, wid, hei]);

        }

        return return_list;

    }

    if(allow_draw){

        var d = new Dict(dict_name);

        min_max = get_min_max(d);
    
        to_draw = get_draw_data(d, min_max, boxInfo);

        d_keys = d.getkeys();

        for(i = 0; i < to_draw.length; i++){

            with(mgraphics){

                if(mode == 0){
                    set_source_rgba(default_col);
                }else if(mode = 1){
                    val = d.get(d_keys[i]);
                    if(val > 5){
                        set_source_rgba([0., 1., 0., 1.]);
                    } else{
                        set_source_rgba([0., 0., 1., 1.]);
                    }
                }
                
                rectangle(to_draw[i]);
                fill();


            }



        }

    }

    

}

function min_max_scaler(val, oldMin, oldMax, newMin, newMax){
    return newMin + (((val - oldMin) * (newMax - newMin)) / (oldMax - oldMin));
}
mgraphics.init();
inlets = 1;
outlets = 2;
setinletassist(0, 'Ctrl In');
setoutletassist(0, 'Address Out');
setoutletassist(1, 'Onset Index Out');

activate = false;
num_tracks = 0;
items = {};
track_col_1 = [0.200, 0.200, 0.200, 1.000];
track_col_2 = [0.502, 0.502, 0.502, 1.000];
full_len = 0;
selected_col = [0.404, 0.792, 0.325, 1.000];
hover_col = [0.749, 0.847, 0.729, 1.000];
basic_col = [0.867, 0.867, 0.867, 1.000];
line_wid= 1;
line_col = [0., 0., 0., 1.];

current_hover_name= '';
current_hover_index = -1;

function get_box_info(obj)
{
    // Return the follwing list about the max object box:
    // [x, y, w, h]

    x = obj.box.rect[0];
    y = obj.box.rect[1];
    w = obj.box.rect[2] - obj.box.rect[0];
    h = obj.box.rect[3] - obj.box.rect[1];

    return [x, y, w, h];
};
boxInfo = get_box_info(this);

function paint(){

    if(activate){
        draw_tracks();

        draw_items();
    }
    

}

function allow_vis(){
    boxInfo = get_box_info(this);
    activate = true;
    mgraphics.redraw();
}

function set_full_len(len){
    full_len = len;
};

function select_item(nam){

    for(item in items){
        items[item]['selected'] = false;
    }

    items[nam]['selected'] = true;
    mgraphics.redraw();
}

function get_entry_draw_data(entry_key){
    this_data = items[key];

    num_to_draw = this_data['num_components'] * this_data['num_onsets'];
    rect_array = [];
    rect_indexes = [];

    for(i = 0; i < this_data['num_onsets']; i++){
        this_onset_data = this_data['onsets'][i]
        this_start = this_onset_data[0];
        this_x = Math.floor(min_max_scaler(this_start, 0, full_len, 0, boxInfo[2] ));
        this_h = Math.floor(boxInfo[3] / num_tracks);

        for(j = 1; j < this_onset_data.length; j = j + 2){
            this_dur = this_onset_data[j];
            this_comp = this_onset_data[j + 1] - 1; 

            this_w = Math.floor(min_max_scaler(this_dur, 0, full_len, 0, boxInfo[2] ));
            this_y = Math.floor(this_h * this_comp);
           
            rect_array.push([this_x, this_y, this_w, this_h])
            rect_indexes.push([j, i]);
        }
    }

    items[key]['rectangles'] = rect_array;
    items[key]['selected'] = false;
    items[key]['hover'] = false;

    items[key]['rect_indexes'] = rect_indexes;
};

function get_draw_data(){

    for (key in items){
        get_entry_draw_data(key)
    }
}

function append_item(){

    var args = arrayfromargs(messagename,arguments);

    onset_list = [];
    getting_name = false;
    this_onset = [];
    this_name = '';
    onset_count = 0;
    components = [];

    for(i = 1; i < args.length; i++){

        if(getting_name == false){
            if(args[i] == 'name'){
                getting_name = true;
            }
            else if(args[i] == '('){
                onset_count++;
                this_onset = [];
            }else if (args[i] == ')'){
                onset_list.push(this_onset);
            }else{
                this_onset.push(args[i]);
            }
        }else{
            components.push(args[i]);
            this_name = this_name + args[i] + ' ';
        } 
    }

    this_name = this_name.slice(0, -1);

    /*
    post('Name: ' + String(this_name) + '\n')
    post('Onset count: ' + String(onset_count) + '\n')
    post('Components: ' + String(components) + '\n')
    post('Onset list:')
    for(i = 0; i < onset_list.length; i++){
        post(String(onset_list[i]) + '\n')
    }
    post('\n');
    */

    entry = {}
    entry['name'] = this_name;
    entry['num_components'] = components.length;
    entry['components'] = components;
    entry['num_onsets'] = onset_count;
    entry['onsets'] = onset_list;

    items[this_name] = entry;
}

function clear_items(){
    items = {};
};

function redraw_after_append(){
    get_draw_data();
    mgraphics.redraw();
}

function set_tracks(num){
    num_tracks = num;
    mgraphics.redraw();
};

function draw_items(){
    with(mgraphics){

        for(item in items){

            rects = items[item]['rectangles'];
            this_col = [];
            if(items[item]['selected']){
                this_col = selected_col;
            } else if(items[item]['hover']){
                this_col = hover_col;
            } else{
                this_col = basic_col;
            }

            for(i = 0; i < rects.length; i++){
                this_rect = rects[i]

                set_source_rgba(this_col);
                rectangle(this_rect);
                fill();

                set_line_width(line_wid);
                set_source_rgba(line_col);
                rectangle(this_rect);
                stroke();
            }
        }
    }
}

function draw_tracks(){

    with(mgraphics){

        track_height = Math.floor(boxInfo[3] / num_tracks)

        for(i = 0; i < num_tracks; i++){
            if(i % 2 == 0){
                set_source_rgba(track_col_1);
            }else{
                set_source_rgba(track_col_2);
            }

            rectangle(0, i * track_height, boxInfo[2], track_height);
            fill();
            
        }
    }
}

function onresize(){
    boxInfo = get_box_info(this);
    get_draw_data();
    mgraphics.redraw();
};

function min_max_scaler(val, oldMin, oldMax, newMin, newMax){
    return newMin + (((val - oldMin) * (newMax - newMin)) / (oldMax - oldMin));
}

function onidle(x, y, button, shift){
    
    if(activate){
        process_hover(x, y);
        mgraphics.redraw();
    }
    
}

function onclick(x, y, button, shift){
    
    
    if(activate){
        process_click(x, y);
        mgraphics.redraw();
    }
    
}

function process_hover(x, y){


    found_item = false;
    for(item in items){

        rects = items[item]['rectangles'];

        for(i = 0; i < rects.length; i++){
            this_rect = rects[i]

            if(x > this_rect[0]){
                if(x < this_rect[0] + this_rect[2]){
                    if(y > this_rect[1]){
                        if(y < this_rect[1] + this_rect[3]){
                            for(key in items){

                                found_item = true;
                                if(key != item){
                                    items[key]['hover'] = false;
                                }
                                else{
                                    items[key]['hover'] = true;
                                    

                                    current_hover_name= key;
                                    //current_hover_index = i;
                                    current_hover_index = items[key]['rect_indexes'][i][1];
                                }
                                
                            }
                        }
                    }
                }
            }
        }
    }

    if(found_item == false){
        current_hover_name= '';
        current_hover_index = -1;
    }
    outlet(1, 'hover ' + String(current_hover_index + 1));
    outlet(0, 'hover ' + String(current_hover_name));
}

function process_click(x, y){
    if(current_hover_index != -1){

        select_item(current_hover_name);

        outlet(1, 'click ' + String(current_hover_index + 1));
        outlet(0, 'click ' + String(current_hover_name));
        
    } 
}